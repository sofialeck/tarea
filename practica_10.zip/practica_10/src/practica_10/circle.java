/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_10;

import practica_10.shape;

/**
 *
 * @author Aleck
 */
public class circle implements shape {

   @Override
   public void draw() {
      System.out.println("Método draw en Circle.");
   }
}