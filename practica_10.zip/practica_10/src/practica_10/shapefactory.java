/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_10;

import practica_10.shape;

/**
 *
 * @author Aleck
 */
public class shapefactory {
     public shape getShape(String shapeType){
      if(shapeType == null){
         return null;
      }
      if(shapeType.equals("CIRCLE")){
         return new circle();

      } else if(shapeType.equals("RECTANGLE")){
         return new rectangle();

      } else if(shapeType.equals("SQUARE")){
         return new Square();
      }

      return null;
   }

}
