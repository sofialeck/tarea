/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica_10;

import java.awt.Shape;

/**
 *
 * @author Aleck
 */
public class Practica_10 {

/**
 *
 * @author Aleck
 */
 public static void main(String[] args) {
      shapefactory shapeFactory = new shapefactory();

      shape shape1 = shapeFactory.getShape("CIRCLE");
      shape1.draw();

      shape shape2 = shapeFactory.getShape("RECTANGLE");
      shape2.draw();

      shape shape3 = shapeFactory.getShape("SQUARE");
      shape3.draw();
   }
}
