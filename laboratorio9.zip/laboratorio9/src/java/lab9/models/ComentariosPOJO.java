/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9.models;

/**
 *

 */
public class ComentariosPOJO {

    private String Nombre;
    private String Comentario;
    
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public String getNombre() {
        return Nombre;
    }
    
    public void setComentario(String Comentario) {
        this.Comentario = Comentario;
    }
    
    public String getComentario() {
        return Comentario;
    }

    
    
}
