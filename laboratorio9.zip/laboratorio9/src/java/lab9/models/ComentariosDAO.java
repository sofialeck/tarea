/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9.models;

import Laboratorio9.utils.Log;
import java.sql.*;
import java.util.*;

/**

 */
public class ComentariosDAO {
    
    private Connection conexion;
     Log l = Log.getInstance("C:\\Users\\Aleck\\Desktop\\FACULTAD");
    
    private void abrirConexion() throws SQLException{
        
        String URI = "jdbc:derby://localhost:1527/Comentarios";
        String username = "fcfm";
        String password = "lsti01";
        
        conexion = DriverManager.getConnection(URI,username,password);
        
    }
    
    private void cerrarConexion() throws SQLException{
        
        conexion.close();
        
    }
    
    public void insertar(ComentariosPOJO POJO) throws SQLException{
        
        
        
        try{
            
            abrirConexion();
            
         
                        
            String sql = "insert into COMENTARIOS values  ('"+POJO.getNombre()+"','"+ POJO.getComentario()+"')";
            
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            
            cerrarConexion();
            
        }catch(SQLException x){
            
              l.write("skhdajk");
        }
       
        
    }
    
    public ArrayList<ComentariosPOJO> buscar(ComentariosPOJO POJO) throws SQLException{
        
        ResultSet re;
        ArrayList<ComentariosPOJO> comentarios = new ArrayList();
        
        String nombre = POJO.getNombre();
        String comentario = POJO.getComentario();
        
        try{
            
            abrirConexion();
                        
            String sql = "select * from COMENTARIOS where NOMBRE = '" + POJO.getNombre()+"' and COMENTARIO like '%"+POJO.getComentario()+ "%'";
            
            Statement stmt = conexion.createStatement();
            ResultSet  mensajes =stmt.executeQuery(sql);
            
            while(mensajes.next()){
                
                ComentariosPOJO dto = new ComentariosPOJO();
                dto.setNombre(mensajes.getString("Nombre"));
                dto.setComentario(mensajes.getString("Comentarios"));
                
                comentarios.add(dto);
            
            }
            
            cerrarConexion();
            
        }catch(SQLException x){
            
            
        }
        
        return comentarios;
        
    }
    
}